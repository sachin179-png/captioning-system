from django.shortcuts import render
from transformers import BlipProcessor, BlipForConditionalGeneration
from transformers import CLIPProcessor, CLIPModel
from PIL import Image
import os
import torch

# ---------- LOAD MODELS ONCE ----------
clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")

blip_processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
blip_model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")


# ---------- CLIP SEARCH FUNCTION ----------
def clip_search(text_query):
    folder = "project/searchaboject"
    image_files = os.listdir(folder)

    # Convert text to embedding
    text_inputs = clip_processor(text=[text_query], return_tensors="pt", padding=True)
    with torch.no_grad():
        text_features = clip_model.get_text_features(**text_inputs)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarities = []

    for img_name in image_files:
        img_path = folder + img_name
        image = Image.open(img_path).convert("RGB")

        # Convert image to embedding
        image_inputs = clip_processor(images=image, return_tensors="pt")
        with torch.no_grad():
            image_features = clip_model.get_image_features(**image_inputs)

        # Normalize image embedding
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)

        # Cosine similarity
        sim = torch.nn.functional.cosine_similarity(text_features, image_features).item()

        similarities.append((sim, img_name))

    # Pick best match
    best_match = max(similarities, key=lambda x: x[0])
    return folder + best_match[1]



# ---------- MAIN VIEW ----------
def home(request):
    image_url = None
    caption = None
    search_result = None

    # HANDLE POST REQUESTS
    if request.method == "POST":

        # 1️⃣ IMAGE UPLOAD + CAPTION (BLIP)
        if "image" in request.FILES:  # safer check
            img = request.FILES["image"]
            img_name = img.name

            # Ensure media folder exists
            media_path = "media"
            if not os.path.exists(media_path):
                os.makedirs(media_path)

            save_path = os.path.join(media_path, img_name)
            with open(save_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)

            # Show uploaded image
            image_url = "/media/" + img_name

            # Generate caption using BLIP
            pil_image = Image.open(save_path).convert("RGB")
            inputs = blip_processor(images=pil_image, return_tensors="pt")
            output = blip_model.generate(**inputs, max_length=20)
            caption = blip_processor.decode(output[0], skip_special_tokens=True)

        # 2️⃣ TEXT SEARCH USING CLIP
        if "query" in request.POST:
            query = request.POST.get("query")
            if query.strip() != "":
                result_path = clip_search(query)
                search_result = "/" + result_path

    # RENDER EVERYTHING
    return render(request, "index.html", {
        "image_url": image_url,
        "caption": caption,
        "search_result": search_result,
    })
